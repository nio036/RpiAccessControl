these are the original repositories that the code is based on.

https://github.com/pimylifeup/Adafruit_Python_CharLCD.git

https://github.com/pimylifeup/attendance-system-frontend.git

https://github.com/pimylifeup/MFRC522-python.git
